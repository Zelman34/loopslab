/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bestloop;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 *
 * @author 01629411
 */
public class BestLoop {

    public static void main(String[] args) {
        List<Integer> w = new ArrayList<>();
        List<Integer> f = new ArrayList<>();
        List<Integer> dw = new ArrayList<>();
        List<Integer> fill = new ArrayList<>();
        List<Integer> fill2 = new ArrayList<>();
        List<Integer> fill3 = new ArrayList<>();
        Random rand = new Random();
        Random rand2 = new Random();
        Random rand3 = new Random();

////        For Loop Code
        int size2 = f.size();
        long for_loop_elapsed_time = 0;
        while (size2 <= 10000) {
            long for_loop_start_time = System.nanoTime();
            for_loop(fill2, rand2);
            for_loop_elapsed_time = System.nanoTime() - for_loop_start_time;
            int conv2 = (int) for_loop_elapsed_time;
            f.add(conv2);
            size2 = f.size();
        }
////       While Loop Code  
        int size = w.size();
        long while_loop_elapsed_time = 0;
        while (size <= 10000) {
            long while_loop_start_time = System.nanoTime();
            while_loop(fill, rand);
            while_loop_elapsed_time = System.nanoTime() - while_loop_start_time;
            int conv = (int) while_loop_elapsed_time;
            w.add(conv);
            size = w.size();
        }
////       Do While Loop Code
        int size3 = dw.size();
        long do_while_loop_elapsed_time = 0;
        while (size3 <= 10000) {
            long do_while_loop_start_time = System.nanoTime();
            do_while(fill3, rand3);
            do_while_loop_elapsed_time = System.nanoTime() - do_while_loop_start_time;
            int conv3 = (int) do_while_loop_elapsed_time;
            dw.add(conv3);
            size3 = dw.size();
        }
////       Average Code
        calc_average(w, f, dw);
    }

    public static void for_loop(List fill2, Random rand2) {
        for (int x = 0; x <= 10000; x++) {
            fill2.add(rand2.nextInt(50));
        }

        fill2.clear();

    }

    public static void while_loop(List fill, Random rand) {
        int y = 0;
        while (y <= 10000) {
            y++;
            fill.add(rand.nextInt(50));
        }
        fill.clear();

    }

    public static void do_while(List fill3, Random rand3) {
        int z = 0;
        do {
            fill3.add(rand3.nextInt(50));
            z++;
        } while (z <= 10000);
        fill3.clear();
    }

    public static void calc_average(List w, List f, List dw) {
        double sum = 0;
        Iterator<Integer> iter1 = w.iterator();
        while (iter1.hasNext()) {
            sum += iter1.next();
        }
        double average = sum / w.size();
        double four_loop_sum = 0;
        Iterator<Integer> iter2 = f.iterator();
        while (iter2.hasNext()) {
            four_loop_sum += iter2.next();
        }
        double average2 = four_loop_sum / f.size();

        double sum3 = 0;
        Iterator<Integer> iter3 = dw.iterator();
        while (iter3.hasNext()) {
            sum3 += iter3.next();
        }
        
        double average3 = sum3 / dw.size();

        System.out.println("********************[ Loop Lab ]*********************");
        System.out.println("*****************************************************");
        System.out.println();
        System.out.println("********[ While Loop Average Execution Time ]********");
        System.out.println("********[ " + average + " nanoseconds " + "]********");
        System.out.println("********[ " + average / 1000000 + " Milliseconds " + "]********");
        System.out.println();
        System.out.println("********[ For Loop Average Execution Time ]********");
        System.out.println("********[ " + average2 + " nanoseconds " + "]********");
        System.out.println("********[ " + average2 / 1000000 + " Milliseconds " + "]********");
        System.out.println();
        System.out.println("********[ Do While Average Execution Time ]********");
        System.out.println("********[ " + average3 + " nanoseconds " + "]********");
        System.out.println("********[ " + average3 / 1000000 + " Milliseconds " + "]********");
    }
}
