/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bestloop;

import static bestloop.BestLoop.for_loop;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 *
 * @author 01629411
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<Integer> f = new ArrayList<>();
        List<Integer> fill2 = new ArrayList<>();
        Random rand2 = new Random();
        int size2 = f.size();
        long for_loop_elapsed_time = 0;
        while (size2 <= 2) {
            long for_loop_start_time = System.nanoTime();
            for_loop(fill2, rand2);
            for_loop_elapsed_time = System.nanoTime() - for_loop_start_time;
            int conv2 = (int) for_loop_elapsed_time;
            f.add(conv2);
            size2 = f.size();
            System.out.println("Elapsed time: " + f);
        }
        double four_loop_sum = 0;
        Iterator<Integer> iter2 = f.iterator();
        while (iter2.hasNext()) {
            four_loop_sum += iter2.next();
        }
        double average2 = four_loop_sum / f.size();
        System.out.println("********[ For Loop Average Execution Time ]********");
        System.out.println("********[ " + average2 + " nanoseconds " + "]********");
        System.out.println("********[ " + average2 / 1000000 + " Milliseconds " + "]********");
    }

    public static void for_loop(List fill2, Random rand2) {
        for (int x = 0; x <= 10000; x++) {
            fill2.add(rand2.nextInt(50));
        }

        fill2.clear();

    }
}
