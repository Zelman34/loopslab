/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bestloop;

/**
 *
 * @author 01629411
 */
public class testing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int y = 0;
        long while_loop_start_time = System.nanoTime();
        while (y <= 10000) {
            y++;
            System.out.println(y);
        }
        long ela = System.nanoTime() - while_loop_start_time;
        System.out.println(ela);
        
    }

}
